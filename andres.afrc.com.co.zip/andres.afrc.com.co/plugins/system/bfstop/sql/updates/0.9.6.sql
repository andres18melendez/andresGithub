alter table `#__bfstop_failedlogin` drop column `password`;
